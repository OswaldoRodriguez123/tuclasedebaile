<div id="contenido" style="display: {{visible}};">
        <!--<img  class="img-responsive" alt="1440x500" data-src="holder.js/1440x500" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABaAAAAH0CAYAAADL8Io6AAAgAElEQVR4nO3dvY7i2rqG0XP/l0JgCYkACREgESAREJAQOXNat8AJtti9dq3qKs9pv7ZxjWCEjf8mFTzM/vx/Hx8fTwAAAAAAGNv/zX0CAAAAAACskwANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAAAAAECEAA0AAAAAQIQADQAAAABAhAANAMzicDg89/v9jx6Px+znyvI8Ho/n9Xp9ns/nL9fN+Xx+Xi6X5/1+n/1ceR9rWVdt2z5vt9vzfD5/+bf2dDo9z+fz836/P7uum/18AYB1E6ABgMnd7/fnZrPpZemh57Pj8dgrrJ9Op9nP9TuXy6XXdez3+8nO6fF4PI/H47Npmt7rZ7PZPJumeR6Px7dbS0vyeDx6r4eU6/VqXX2jbdvn+Xx+brfbouvYbDbPw+EQu78AAAI0ADC5/X6/ygB9Pp97X9eU4bZUyQ8Em80mfj6v+Fka1b6y3W7fak0txeVyGeX+D3E+n62rL3Rd9zwej6NcR9M0z8vlMvt6AwDWRYAGACZVGjffJRY+Ho+i61pqgO66rngHZfJ8SqJ+icPhYPRAgdPptKoAvZZ1dbvdindu97Hb7Yw/AgBGI0ADAJOpiZvvEKC7rnvudrtVBOianZSpezrW7lSRbbj0s+hjjAC9pnWV/lGgaZrn7Xabfe0BAO9PgAYAJlMTN98hQNeEoCUG6NvtVhWqxj6PmqA/JLKJ0D+b4ln8ZGiAXtO6GmvkRh9mQwMAQwnQAMAkamfILj1Al44UeVlagO66rvq/8o99LofDYdKwudvtjOP4Rtu2kz6PvxkaoNeyrqaex+1HGgBgKAEaAIi7Xq/V8WPJAXpItF1agB4ylmDM80jN5n2357EktT+yjG1IgF7LuprrWTRN40caAKCaAA0ARA2Jz5vNsgP0kB2VSwqeQ3dUjnUepS9yHNvlcpn9WSzRXPH2s9oAvZZ1VTNDf0yHw2H2tQgAvCcBGgCIGSNcLTVADw3rSwnQj8ejehf3y1jnMveL7uzy/NrUoyv+pjZAr2VdLeGHgKX+PQYAlk2ABgBG13XdaNFqicGjbdvB0XYpAXqMl7KNcR5rGPOwVlO9uC/xbNayroaM+xnTUv5uAQDvRYAGAEZ1v99H/W/iSwzQY+yoXELIGWtH5Zz3tGma5/F4fN5ut+f9fn/e7/fn6XSqXoN2Qf/b3NHzpSbirmVdDfmuHg6H5/V6/e91XC6XQT8qLPFvMgCwbAI0ADCKruuep9Np9Oi0tNgxdF7yy9wBesy5uHOdy+Fw+Dbq1a5Hs6Az62So0gC9pnVVs/t5t9s9H4/HXz/zer1Wfa5Z0ABAKQEaABjsdrvFXo61pAA9ZoybM0CP/TKzoedzPB5j968mFm6329nX2lKUzjp/7bJNaNv2V66rmnnzfXdc3263qu986bMAAH43ARoAqHa/3+Mv+FpSgB5zFu6cAXrsnepDz6d0F2bTNEUBrCa2f7dz9DcpGf3QNM3s57vGdVUzT/92u/X+/JpQ738JAAAlBGgAoNj1eo2H55elBOixo+1cAbp2x+N3hpxPzUvijsdj8XotPYaXEf5Hyfd87rEya11Xpcco3Wndtu3b/P0CAN6TAA0A9PZ4PKpmhg6xhABdE7OWGHC6ros8vyHnVBP2a3aRll73brebfd0tQcl9W1K0X8u6qvnBqGZ3cs0uay/rBAD6EqABgN4SIfYncwfoseclv8wRoGsiUx9Dzql0rEntHN2aMQO/PbB1XVd0v67X6+znvLZ1VRPSa+Yz1+zmLhnzAQD8bgI0ANDb0ABdM0N57gCdirZTB+jL5RK5js1mWIAuPVbpmISXmsD23dp7jaGpMTTcdV1XfeyS71Pp933u7+oa1tVnpaOOakN6zRiOJe14BwCWTYAGAHobEqAvl0vVv58zapX89/fS/4o/ZYBu27b3+dWM6JhyPdW+/OzxeIwa2IbsjG+aZtDu6tofRQ6HQ9FxSn+0mOt7uqZ19Vn6Gf/Tkv+GAQDvTYAGAHqrDdCv/5r/TgG6JNq+AtZS403JzvOandK151VzrCHrYeyYVxMfh4bC2pdI1kTvkvEStTtvE959XQ1ZX0N2JZfutm6aZvZnDQC8BwEaAOitNCA3TfM/L/Z6pwBdEmPO53PxtU0VoM/nc/E5lT6j2nObar7tS+kImD4vjCu5v5+VjuIY8hLJmrEfJd+BITtvx7aGdfXxUfdjw5A53DX37bfPSQcA+hGgAYDeSiLrfr//V5x4lwBdsoPyFZOWGKBLdlA2TfPfCFf6jGrPr3TH5ZBjJY9X87mbzX92DZcEvNrRG6fTqep+lRzj887bx+PxvFwuz+Px+K851Ofz+Xm9Xv/nx6kxrWVd1fy4MeTv5dTHAwB+DwEaAOitT2Rtmuav81TfIUDXRtulBejSGcX/3CE7VbyreSnlkHtSE3D7BOLScS3/1DcO147eKI3cNd+D1/pp2/Z5Op2K7sV2u32eTqdBO5DXuq5qdiQP+XtZM7pk6As1AYDfQYAGAHr7KbIeDodvQ9I7BOjSecm115YO0CXx6vP4hKniXelxht6z5A7P6/Va/Nl9jzFk9EbtLuPS4F27C/yfjsfjKCF6Letq6p3cNX+fh8ycBgB+DwEaAOjtb4Fiv9/3CipLD9A185Jrry0ZoEvO5auX000VvdYSCl9qR2T89AK/2s8dEgeHzLYe4rv/QfHb1pUADQCshQANAPT2OVDs9/ui/4K95ABdGm0/79RcSoAu3S371fObInqVjniYKxSWvNStdOxJn5BXO3pj6L2qjd5jORwOk4wOWfK6qtn1PuQ6av4+H4/HwX+zAID1E6ABgN5egeJ4PFaF4aUG6CHzkmuvLRWgS8Lh3+YPTxG9atbCHKGwdIdnzXW9fB6XUTt646sfSErVhvQx7Xa74gi9pnVVc8+GXMcc9w4A+B0EaACgt67rqnYlviw1QB+Px97n83lecu21JcJNyRzi715ON0X0qlkLf7v3iftTEgo/qx1fsdvt/udzanchl+za/pua4yaURug1ravSz2yaZtB1tG1bfEwBGgDoQ4AGACazxABdMuLgq3nJtdc2drhp27Zot+x397X0GU21FobOm53ymCUvs/zqeLWjN4bG1Nr7lFTyXVnTukrepyUdEwBYPwEaAJjM0gL0GPOSa69t7HBT8sKyv43eeCl9RlOthaWGwq88Ho/q8Rm1//a7Xe0lanb0pvV9DmtaV6WfKUADAEslQAMAk1lagB4z2s4ZoEtGPnwe8/CV0mc01VpYaij8m8vlUny8Icb6rpxOp0nPu6/PM7KX8IyTxyz9TAEaAFgqARoAmMySAnRJHOyzs3SuAP14PEaPeKXPaKq1sNRQ+J3aOc6lfvqBpETJDzNT6vOdWdO6StyfJR4TAFg/ARoAmMxSAnTpiIM+5zBHgO66rmjWcN/QVvqMploLSw2FPz2jmnEaJfrsai8x5Hy32+3zdDo9b7fb836/P+/3+/N2uz3P53P1XOyS7+Ka1lXpZwrQAMBSCdAAwGSWEqBLQljfnaVzBOiSUQklkbL0GU21FpYaCn9S+0LBvvrsau+rbduqc9jv972+q23bDtph/dNLFte0rmqewdDnP8cxAYD1E6ABgMksIUCPPS+59tqGhpuS4zVN82zbtvdnlz6jqdbCUkNhH6m5ypfLZdbvaNM0VedQ8j387LtxOGtaV6WfKUADAEslQAMAk5k7QJcev2Rn6ZQBunSsQ2kgLH1GU62FpYbCvs9sjBEU6fh3vV6f2+221/Gbphm0+7o2Ql+v10U9YwF63DUIAKyPAA0ATGbOAN11Xe+wVhOlpgzQJS+2qzlO6TOaai0MDYU1ozDGCtAfH+UvjPxO0zQ/vhhzjPN9zW8+Ho//MzpjaHx+qYnyx+PxV6yr0s8cGoO7rpv8mADA7yBAAwCTmTNAp+Yl115bbbgpiV2lozdeSp/RVGthaOyq2XE7ZoD++Ph4Xi6X4nP4yu12m/S7+09d11Wtq69cr9fia//u+7mmdVWzLoZcxxz3DgD4HQRoAGAycwXoKaLtFAG6bdui0Ru1kXKK6LWmUFhqyEv4NpvvdwC/o5I1/dOaW9O6qlkbQ65DgAYAUgRoAGAycwTo9Lzk2murCTcl4fJwOFTfsymiV9u2bxEKEzuNS39I+Gys3cdLURPk/zb+Y03rqmRk0JDv4kvN3+fT6TT7+gEAlk+ABgAmM0eALo1D+/2+Suks26Zpvv28z2Gn9N7tdrvqa6kJeN/527N5h1A45kswX0p/FFl79Bv7uaxlXdV8F4dcx5wv6QQA1k2ABgAm8w4Beik+R7Gae7cUf3s2Q+9JqePxWHzMMV6091nJSyT/Zs4Z0GN79wCdWldTB+iaedy1/2MEAPhdBGgAYDICdH0UW2OAnjqwTX28r5TMI/9O0zTPrutm/06PYewAvZZ1NfWO/aX8DwEAYH0EaABgMgJ0fwJ02Wf1UXq8pmlGXf9DZz9/NmTO95L8tgDdd129Q4BO/A8BAGB9BGgAYDICdH+/IUBPHbyGPoOhasLoT67Xa/x723Xd836/P+/3+/N8Pj/P5/PzcDiMtvt17NC6lnVV850fMhJjCf9DAABYJwEaAJiMAF0fqdYYoC+Xy2Troeu64mON+bK/mmvto2maZ9u2o53j+Xx+Ho/HXi/WHOsFdGMH47Wsq8fjUfzZQ55J6YtUd7vdaN8PAGDdBGgAYDICdH+/IUDXXFNtYKs51li7i2tC4pC1Umu73c5y3JqXMo79rJe6rqZcC6XHOh6Pozx/AGD9BGgAYDICdH1IWmOA/viYLrDNOd+2dGdpjTF2I9eMYBjjRYilc7H77Lxdy7qaaizG1OM+AIDfRYAGACYjQNcHsbUG6Jo4WxM9S48z1gsIp1x/Q4N5zbkO3SVes6777Lxdy7o6nU7F13G73Yqvo+Y4XkAIAPQlQAMAkxGg+/stAbomfJVGz7Zti48xxniB2mdWuiP4ZbfbDdqRXHO+2+120DFrdvj2ef5rWVe3222StVs6fmW73Q7+fgAAv4cADQBMRoDu77cE6NroWbIGpoiRn3VdVxz1Nps/LxWs+bebzfAXJ055zJq4utn026m8pnVVc49KXkw5VeQGAH4vARoAmMwcAbpt2+f9fo+7XC5F17Xb7b79vM//vb3rukmuo/YZfeenZ1Sz47fv/NnaFwAOnW1cEyc3mz/jE4b84DDkO1PzQsCasPp4PKqee0n4XMu6qnkmh8Oh12fX/lBSM+YDAPi9BGgAYDJzBOilXlvtS8+mUPqMhh7veDwWH7Npmh9n0HZdVzULeOjuztqdvZ+jYc192WyGjcWoPffNpv+LEG+3W/WYkZK/B2tZV9frtepe9flRoOYeGb8BAJQSoAGAyQjQfwjQf9TuJn1Fz8/jBrque16v10ki52dd11Udt2maf0Xj2s/abPrvgP1K7fiP17r+2+7Y2+1WNfO59juzpnU1ZB18FdRvt1tVRH/dm7n/RgEA70WABgAmI0DXx7QplT6jMY45JExuNv8ZabLf7wd/ztDnUjvC4rtoW3sttWMSanfcfnUvx3gmLz/tTF7zuho6y3673f73Ompj9mbz9Q8lAAA/EaABgMkI0OMFqaTSZzTX2kgYst5K54C//LRbuTZqv15oWHMttbtjU2pfdLiGdfXxMWw3/JjsfgYAagjQAMBkBOg/BOh/qw2tYxnyTNq2rR698VMkHhIfa69pyPiKse12u0G7bt95Xf1T7Q8cY7H7GQCoJUADAJMRoMePUgmlz2is4865y3PIbuGPj/pRD5fLpdfnDxnF0fcYnw0d+zDWc6kZvbGWdTXWOhtD7UgXAAABGgCYjAD9hwD9tcfjMUssvF6v1edcG2pL18CQnby1Efd4PM4WPMeMnu+4rr7Sdd0s41GOx+Psf5cAgPclQAMAkxGg6+PjlEqf0djHH+sleH3Vzhf++KgfVVGzM3bITt7dbld9jXNF6LHj7Tutq5/W3JQxfcjaAQD4+BCgAYAJCdB/CNDfu91uk0S2oTs7a3ej1o7FGDIHeEgQnTJCN00TG/fwLuvqJ4/HY5Kd0EPnbwMAfHwI0ADAhAToPwTonz0ej+d2u43FtdoI/HI6naqOO/TZD5kDPOT7dLlc4vF2t9uNOjP5HddVX13XRWdCH49H8RkAGIUADQBMRoAeL0ImlT6j5Ll0XVcder+LnENfbFezljebcV5K17ZtdQjebreDomLbtpHo2TTNZOF2yeuqxtg/DCR3oAMAv5MADQBMRoAWoGu1bTt4DMRutxtlrnDXddU7aMeKrENGcYwxHuJ+v48ylmO73T4vl8tsO22XtK6Grsnz+TwoRG+32+f5fLbrGQAYnQANAEym67rn/X4v8i4xpPTa5tgp2VfpM5r6Pl+v1+fxePwxAjdN89zv98/z+Tzq/W7btvgeJe5V7TmMeR7/fB59ZhKnnska1tVYbrfb83Q69Xoe+/3+eTqd7HgGAKIEaAAA3trj8XjbHy7W6G+Bfu7zKrWWdfXV80jP2QYA+CcBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAE+DaOIAAABZSURBVACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAIAIARoAAAAAgAgBGgAAAACACAEaAAAAAICI/weE9INseiQPCAAAAABJRU5ErkJggg==">-->
<!--     <section class="margin-top-100">
    <div class="container">
    <div class="row"> 
    <div class="margin-top-40 col-md-12">    
        <h2 class="text-center" style=" font-weight: bold;">¡APRENDE A BAILAR SALSA CASINO EN 90 DÍAS!</h2>
    </div>
    </div>
    </div>
    <div class="container margin-top-50">
    <div class="row">
        <div class="col-md-12 text-center">        
                <a href="#/empezar" class="btn btn-azul-claro btn-lg text-uppercase">EMPEZAR</a>        
        </div>
    </div>
    </div>
    </section> -->

    <section class="banner_arriba">
    <div class="container">
<!--     <div class="row">  -->

        <div class="col-xs-12 hidden-lg hidden-md"><img class="img-responsive imagen_arriba" src="img/imagenes_nuevas/inicio_arriba.jpg"></div>
    
                <div class="col-md-offset-8 col-lg-offset-9 col-md-3 div-registro">
                <div class="text-center div-titulo">Empieza Ya</div>

                <div class="alert alert-warning" role="alert" ng-show="vduplicado" >El correo ya se encuentra registrado.</div>
                <div class="alert alert-warning" role="alert" ng-show="vincorrecto" >Por favor verifique los datos introducidos.</div>

                <form name="MyForm" id="MyForm" role="form" >
                    
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">


                            <div class="col-sm-12" style="padding-top:10px">
                                 <div class="form-group">

                                    <div class="fg-line">
                                    <input type="text" class="form-control input-sm" name="nombre" id="nombre" placeholder="Nombre" ng-model="formInfo.Nombre">
                                    </div>
                                    
                                 </div>
                                 <span ng-show="nombreRequired">{{nombreRequired}}</span>
                                </div>


                               <br>

                    
                                <div class="col-sm-6">
                                 <div class="form-group">

                                    <div class="fg-line">
                                    <input type="email" class="form-control input-sm" name="email" id="email" placeholder="Correo electrónico" ng-model="formInfo.Email">
                                    </div>
                                    
                                 </div>
                                 <span ng-show="emailRequired">{{emailRequired}}</span>
                                </div>


                                <div class="col-sm-6">
                                 <div class="form-group">
                                    <div class="fg-line">
                                    <input type="email" class="form-control input-sm" name="email_confirmation" id="email_confirmation" placeholder="Repite correo electrónico" ng-model="formInfo.EmailConfirmation">
                                    </div>
                                    
                                 </div>
                                  <span ng-show="emailConfirmationRequired">{{emailConfirmationRequired}}</span>
                                 </div>


                               <br>

                                <div class="col-sm-6">
                                 <div class="form-group">
                                    <div class="fg-line">
                                    <input type="text" class="form-control input-sm input-mask" name="celular" id="celular" placeholder="Número Móvil" ng-model="formInfo.Celular" ui-mask="(999) 999-9999"  ui-mask-placeholder ui-mask-placeholder-char=""/>
                                    </div>
                                 </div>
                                    <span ng-show="celularRequired">{{celularRequired}}</span>
                               </div>

                                <div class="col-sm-6">
                                 <div class="form-group">
                                    <div class="fg-line">
                                    <input type="text" class="form-control input-sm input-mask" name="telefono" id="telefono" data-mask="(000)000-0000" placeholder="Número Local" ng-model="formInfo.Telefono" ui-mask="(999) 999-9999"  ui-mask-placeholder ui-mask-placeholder-char=""/>
                                    </div>
                                 </div>
                                    <span ng-show="telefonoRequired">{{telefonoRequired}}</span>
                               </div>
                                 

                               <br>

                                <div class="col-sm-12">
                                          <div class="form-group">
                                                <div class="fg-line">
                                                  <div class="select">
                                                      <select class="form-control" id="como_nos_conociste_id" name="como_nos_conociste_id" placeholder="Seleccione>>" ng-model="formInfo.ComoNosConociste">
                                                      <option value="">¿Cómo nos conociste?</option>
                                                      <option value="1">Por un amigo</option>
                                                      <option value="2">Redes Sociales / Internet</option>
                                                      <option value="3">Prensa</option>
                                                      <option value="4">Televisión</option>
                                                      <option value="5">Radio</option>
                                                      <option value="6">Otros</option>
                                                      </select>
                                                </div>
                                                </div>

                                    </div>
                                        <span ng-show="ComoNosConocisteRequired">{{ComoNosConocisteRequired}}</span>
                                 </div>

                                 <br>



                                    <div class="col-sm-12">
                                          <div class="form-group">
                                                <div class="fg-line">
                                                  <div class="select">
                                                      <select class="form-control" id="region" name="region" placeholder="Seleccione>>" ng-model="formInfo.Region">
                                                      <option value="">Region / Ubicacion</option>
                                                      <option value="1">Sede Risaralda - Pereira</option>
                                                      <option value="2">Sede Maicao</option>
                                                      </select>
                                                </div>
                                                </div>

                                    </div>
                                        <span ng-show="RegionRequired">{{RegionRequired}}</span>
                                 </div>

                                 <br>

                                    <div class="col-sm-12 ">

                                        <label for="correo">Sexo</label>
                                        <div class="form-group">
                                          <div class="p-t-10">
                                        <label class="radio radio-inline m-r-20">
                                            <input name="sexo" id="mujer" value="F" type="radio" ng-model="formInfo.Sexo">
                                            <i class="input-helper"></i>  
                                            Mujer <i class="zmdi zmdi-female p-l-5 f-20"></i>
                                        </label>
                                        <label class="radio radio-inline m-r-20 " style="margin-top:10px">
                                            <input name="sexo" id="hombre" value="M" type="radio" ng-model="formInfo.Sexo">
                                            <i class="input-helper"></i>  
                                            Hombre <i class="zmdi zmdi-male-alt p-l-5 f-20"></i>
                                        </label>
                                        </div>
                                       </div>
                                        <span ng-show="sexoRequired">{{sexoRequired}}</span>
                                   </div>

                                    


                                <div class="clearfix"></div>

                            <div class="text-center">

                            <br><br>

                               <button type="button" ng-show="enviando" class="btn btn-blanco-grande text-uppercase m-r-10 f-22 guardar" id="guardar" name ="guardar" ng-click="saveData()">Llévame</button>
                               <div class="alert alert-info" role="alert" ng-show="procesando" >Espere un momento estamos procesando</div>
                               <br>
                               
                            </div>
                             <br>
                        </form>


                </div>
                </div>
<!--                 </div> -->

    </section>

<section class=" padding-top-bottom-50">
<div class="container">
<div class="row">
    <div class="col-md-12 vcenter text-center">
        <h3>NUESTRAS VENTAJAS</h3> 
        <br>
        <h3>CON MÁS DE 10 AÑOS DE EXPERIENCIA HEMOS AYUDADOS A MILES DE ALUMNOS A LOGRAR SUS OBJETIVOS</h3> 

        <br>
        <!-- <div class="text-left">
        <p><span class="text-success">✔</span>   Profesor internacionales con más de diez años de experiencia <br>
            <span class="text-success">✔</span>  Nos encanta que nuestros alumnos logren sus metas, por esa razón, les reconocemos su esfuerzo en cada nivel superado<br>
            <span class="text-success">✔</span>  Nos caracterizamos por crear grandes eventos de talla regional, nacional e internacional, con una experiencia de montaje de grandes escenarios<br>
            <span class="text-success">✔</span>  Nuestros alumnos cuentan  con la plataforma tecnológica para gestionar múltiples funcionalidades 

		</p>
        </div> -->

    <div class="col-md-3 padding-top-bottom-20 text-center">
        <img src="img/ic_experiencia.png" class="img-circle img-responsive img-center img-150" alt="" > 
        <br>             
        <span> Profesores internacionales con más de diez años de experiencia </span>
    </div>

    <div class="col-md-3 padding-top-bottom-20 text-center">
        <img src="img/ic_certificado.png" class="img-circle img-responsive img-center img-150" alt="" > 
        <br>             
        <span> Reconocemos el  esfuerzo de nuestros alumnos , por lo tanto le otorgamos títulos de certificación  </span>
    </div>

    <div class="col-md-3 padding-top-bottom-20 text-center">
        <img src="img/ic_eventos.png" class="img-circle img-responsive img-center img-150" alt="" > 
        <br>             
        <span> Creamos eventos para nuestros alumnos  talla regional, nacional e internacional </span>
    </div>

    <div class="col-md-3 padding-top-bottom-20 text-center">
        <img src="img/ic_tecnologia.png" class="img-circle img-responsive img-center img-150" alt="" > 
        <br>             
        <span> Nuestros alumnos cuentan  con la plataforma tecnológica para gestionar múltiples funcionalidades  </span>
    </div>


    <div class="col-md-12 vcenter text-center">
    <br><br><br>
        <a class="btn btn-azul-claro-grande btn-lg text-uppercase subir">INICIA HOY</a>
    </div>
    </div>
</div>
</div>
</section>

<section class="padding-top-bottom-50 fondo-clouds">
  <div class="container">
  <div class="row">
    <h3 class="text-center">UN NUEVO ESTILO DE VIDA</h3>  

     <div class="col-md-4 padding-top-bottom-20 text-center">
        <img src="img/caso-8.jpg" class="img-circle img-responsive img-center img-150" alt="" >
        <h4>GEOVANI RIVERA</h4>                    
        <blockquote> <span style="font-size:35px">“</span> &nbsp; Pudimos bailar en nuestra boda, esto sin ustedes no hubiese sido posible, un sueño más cumplido, gracias a la academia y sus profesores .</blockquote>
    </div>
    <div class="col-md-4 padding-top-bottom-20 text-center">
        <img src="img/caso-5.jpg" class="img-circle img-responsive img-center img-150" alt="" >
        <h4>HERNAN PALACIO</h4>  
        <blockquote> <span style="font-size:35px">“</span> &nbsp;  Les agradezco mucho, me hicieron ver la música de una manera distinta , ver la música de esta forma es algo que me aporta mucho a la hora de estructurar una canción.</blockquote>   
    </div>
    <div class="col-md-4 padding-top-bottom-20 text-center ">
        <img src="img/caso-6.jpg" class="img-circle img-responsive img-center img-150" alt="" >
        <h4>ANDREA BETANCOUR</h4>  
        <blockquote> <span style="font-size:35px">“</span> &nbsp;  Excelente "Tu Clase de Baile" un vivo ejemplo de que la dedicación y el esfuerzo dan como resultado grandes logros.</blockquote> 
    </div>
  </div>
  </div> 
</section>


<div class="banner_abajo">
    <section class="margin-top-bottom-50">
       <div class="container">
        <div class="row"> 


        <div class="col-md-6" style="color:black">

            <br>
            <h3>Este es tu momento</h3> 

            <span>Verás que todos podemos aprender a bailar , podrás recibir clases grupales o personalizadas , con una metodología acorde para tu aprendizaje.</span>
            <br><br>

            <h3>¿Qué hacer para empezar?</h3> 
            
            <span>Llena el formulario “empieza ya” y un asesor te llamará para explorar las clases ideales para ti, nuestras ofertas actuales y tus facilidades de pago. ¡Estás a solo un clic de tu primera clase de baile.</span>
            <br><br>

            <a class="btn btn-rosado btn-lg text-uppercase subir">Empieza ya</a>

        <br><br><br>        <br><br><br>
        
        </div>


         
        </div>
       </div>
    </section>
</div>
</div>
<script type="text/javascript-lazy">
   loadjscssfile("js/function/cargar.js", "js");

   $(".subir").click(function(){

      $("html, body").animate({ scrollTop: 0 }, "slow");

   });

   $('#email').bind("cut copy paste",function(e) {
        e.preventDefault();
    });

    $('#email_confirmation').bind("cut copy paste",function(e) {
        e.preventDefault();
    });
</script>